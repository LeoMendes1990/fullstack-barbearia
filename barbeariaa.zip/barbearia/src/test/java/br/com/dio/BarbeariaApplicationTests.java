package br.com.dio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BarbeariaApplicationTests {

	@Test
	void contextLoads() {
	}

}
